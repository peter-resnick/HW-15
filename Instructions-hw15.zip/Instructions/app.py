import datetime as dt
import numpy as np
import pandas as pd

from flask import (
    Flask,
    render_template,
    jsonify,
    request,
    redirect)

#################################################
# Flask Setup
#################################################
app = Flask(__name__)

#################################################
# Database Setup
#################################################
from flask_sqlalchemy import SQLAlchemy
# The database URI
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///db/belly_button_biodiversity.sqlite"

db = SQLAlchemy(app)
df = pd.read_sql_table("samples", db.session.bind)
# class Emoji(db.Model):
#     __tablename__ = 'emoji'

#     id = db.Column(db.Integer, primary_key=True)
#     emoji_char = db.Column(db.String)
#     emoji_id = db.Column(db.String)
#     name = db.Column(db.String)
#     score = db.Column(db.Integer)

#     def __repr__(self):
#         return '<Emoji %r>' % (self.name)

# Create database tables
@app.before_first_request
def setup():
    # Recreate database each time for demo
    # db.drop_all()
    db.create_all()

class Otu(db.Model):
    __tablename__ = 'otu'

    id = db.Column(db.Integer, primary_key=True)
    otu_id = db.Column(db.Integer)
    lowest_taxonomic_unit_found = db.Column(db.String(64))
    
    def __repr__(self):
        return '<Otu %r>' % (self.out_id)

class Samples(db.Model):
    __tablename__ = 'samples_metadata'

    id = db.Column(db.Integer, primary_key=True)
    SAMPLEID = db.Column(db.Integer)
    EVENT = db.Column(db.String(64))
    ETHNICITY = db.Column(db.String(64))
    GENDER = db.Column(db.String(64))
    AGE = db.Column(db.Integer)
    WFREQ = db.Column(db.Integer)
    BBTYPE = db.Column(db.String(64))
    LOCATION = db.Column(db.String(64))
    
    def __repr__(self):
        return '<Otu %r>' % (self.out_id)

#################################################
# Flask Routes
#################################################

@app.route("/")
def home():
    """Return the dashboard homepage."""
    return render_template("index.html")

@app.route("/names")
def names():
    """List of sample names.
    
    Returns a list of samples names in the format
    [ 
        'BB_940',
        'xx_xxx',
        'xx_xxx',
        ........
    ]
        """
    # bbb = pd.read_csv("/DataSets/belly_button_biodiversity.csv")
    # bbb = bbb.

    def names():
        results = db.session.query(Otu.otu_id, Otu.lowest_taxonomic_unit_found).all()

        
        names = []
        for result in results:
            names.append(result[1])
        return jsonify(names)


    # # query for the top 10 emoji data
    # results = db.session.query(belly_button_biodiversity.name, Emoji.score).\
    #     order_by(Emoji.score.desc()).\
    #     limit(10).all()

    # # Select the top 10 query results
    # names = [result[0] for result in results]
    # #scores = [int(result[1]) for result in results]

    # # Generate the plot trace
    #plot_trace = {
    #  #   "x": emoji_char,
    #   #  "y": scores,
    #    # "type": "bar"
    # }
    # return jsonify(names)



@app.route("/otu")

    # """List of OTU descriptions
    
    # Returns a list fo OTU descriptions in the following format
    
    # [
    #     "Archaea;euryachaeota;.....
    #     .....;,,,,,,;,,,,,
    # ]
    # """
def otu():
    results = db.session.query(Otu.otu_id, Otu.lowest_taxonomic_unit_found).all()

    otus = []
    for result in results:
        output = "BB_" + str(result[0])
        otus.append(output)
    return jsonify(otus)
    # query for the emoji data using pandas
    # query_statement = db.session.query(Emoji).\
    # order_by(Emoji.score.desc()).\
    # limit(10).statement
    # df = pd.read_sql_query(query_statement, db.session.bind)
    
    # Format the data for Plotly
    # plot_trace = {
    #         "x": df["emoji_id"].values.tolist(),
    #         "y": df["score"].values.tolist(),
    #         "type": "bar"
    # }
    # return jsonify(plot_trace)

@app.route("/metadata/<sample>")
    # """Return metadata for a given sample.
    
    # Args: Sample in the format : `BB_940`
    
    # Returns a json dict of sample metadata in the format
    # {
    #     AGE: 24,
    #     BBTYPE: 'I',
    #     ETHNICITY: 'Caucasion',
    #     GENDER: 'F',
    #     LOCATION: 'Beaufort/NC',
    #     SAMPLEID: 940,
    # }
    #"""
def meta_samples(sample):
    results = db.session.query(Samples.SAMPLEID, Samples.AGE, Samples.BBTYPE, Samples.ETHNICITY, Samples.GENDER, Samples.LOCATION).filter(Samples.SAMPLEID == sample).all()

    
    meta = []
    for result in results:
         meta.append({
            "AGE": result[1],
            "BBTYPE": result[2],
            "ETHNICITY": result[3],
            "GENDER": result[4],
            "LOCATION": result[5],
            "ID": result[0]
         })

    return jsonify(meta)

    # # query for the top 10 emoji data
    # results = db.session.query(Emoji.name, Emoji.score).\
    #     order_by(Emoji.score.desc()).\
    #     limit(10).all()
    # df = pd.DataFrame(results, columns=['name', 'score'])

    # # Format the data for Plotly
    # plot_trace = {
    #         "x": df["name"].values.tolist(),
    #         "y": df["score"].values.tolist(),
    #         "type": "bar"
    # }
    # return jsonify(plot_trace)


@app.route('/samples/<sample>')
    # """OTU IDs and Sample Values for a given sample.

    # Sort your Pandas DataFrame (OTU ID and Sample Value)
    # in Descending Order by Sample Value

    # Return a list of dictionaries containing sorted lists  for `otu_ids`
    # and `sample_values`

    # [
    #     {
    #         otu_ids: [
    #             1166,
    #             2858,
    #             481,
    #             ...
    #         ],
    #         sample_values: [
    #             163,
    #             126,
    #             113,
    #             ...
    #         ]
    #     }
    # ]
    #"""
def samples_data(sample):
    new_df = df[['otu_id',sample]]
    newer_df = new_df.sort_values(sample,ascending=False,inplace=False)
    first = 0
    second = 0
    sample_data = []
    otu_ids = []
    sample_values = []
    for i in range(0,10):
        column1 = int(newer_df.iloc[i,0])
        column2 = int(newer_df.iloc[i,1])
        otu_ids.append(column1)
        sample_values.append(column2)

    sample_data.append({"otu_ids":otu_ids,"sample_values":sample_values})
    return jsonify(sample_data)   
   


@app.route('/wfreq/<sample>')
    # """Weekly Washing Frequency as a number.

    # Args: Sample in the format: `BB_940`

    # Returns an integer value for the weekly washing frequency `WFREQ`
    # """
def wfreq(sample):
    results = db.session.query(Samples.SAMPLEID, Samples.WFREQ).filter(Samples.SAMPLEID == sample).all()

    
    meta = []
    for result in results:
         meta.append( 
            {"WFREQ": result[1]}
            )
    return jsonify(meta)


@app.route("/pie")
def piechart():
    df = df[['otu_id','BB_941']]
    df = df.sort_values('BB_941',ascending=False,inplace=False)
    label = 0
    value = 0
    for i in range(0,10):
        label = int(df.iloc[i,0])
        value = int(df.iloc[i,1])
    labels = label
    values = value 
    data = [{
    "labels": labels,
    "values": values,
    "type": "pie"}]

    return jsonify(data) 
    
if __name__ == '__main__':
    app.run(debug=True)